﻿namespace TWSS
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.Tname = new System.Windows.Forms.ToolStripStatusLabel();
            this.superManag = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel5 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel10 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel7 = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel6 = new System.Windows.Forms.ToolStripStatusLabel();
            this.systemTime = new System.Windows.Forms.ToolStripStatusLabel();
            this.time2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.工作量登记ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.教学统计ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.竞赛培训ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.科学研究ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.其他ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.效绩统计ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.工作量查询ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.个人管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.超级管理员ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.帮助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.计算器ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关于ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.退出系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.关闭系统ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.toolStripStatusLabel2,
            this.toolStripStatusLabel3,
            this.Tname,
            this.superManag,
            this.toolStripStatusLabel5,
            this.toolStripStatusLabel10,
            this.toolStripStatusLabel7,
            this.toolStripStatusLabel6,
            this.systemTime,
            this.time2});
            this.statusStrip1.Location = new System.Drawing.Point(0, 822);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1409, 25);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.statusStrip1_ItemClicked);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(0, 20);
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.BackColor = System.Drawing.Color.White;
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(193, 20);
            this.toolStripStatusLabel2.Text = "                                              ";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.BackColor = System.Drawing.Color.White;
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(69, 20);
            this.toolStripStatusLabel3.Text = "欢迎您：";
            // 
            // Tname
            // 
            this.Tname.BackColor = System.Drawing.Color.White;
            this.Tname.Name = "Tname";
            this.Tname.Size = new System.Drawing.Size(39, 20);
            this.Tname.Text = "老师";
            // 
            // superManag
            // 
            this.superManag.BackColor = System.Drawing.Color.White;
            this.superManag.Name = "superManag";
            this.superManag.Size = new System.Drawing.Size(0, 20);
            // 
            // toolStripStatusLabel5
            // 
            this.toolStripStatusLabel5.BackColor = System.Drawing.Color.White;
            this.toolStripStatusLabel5.Name = "toolStripStatusLabel5";
            this.toolStripStatusLabel5.Size = new System.Drawing.Size(81, 20);
            this.toolStripStatusLabel5.Text = "                  ";
            // 
            // toolStripStatusLabel10
            // 
            this.toolStripStatusLabel10.BackColor = System.Drawing.Color.White;
            this.toolStripStatusLabel10.Name = "toolStripStatusLabel10";
            this.toolStripStatusLabel10.Size = new System.Drawing.Size(105, 20);
            this.toolStripStatusLabel10.Text = "                        ";
            // 
            // toolStripStatusLabel7
            // 
            this.toolStripStatusLabel7.Name = "toolStripStatusLabel7";
            this.toolStripStatusLabel7.Size = new System.Drawing.Size(37, 20);
            this.toolStripStatusLabel7.Text = "       ";
            // 
            // toolStripStatusLabel6
            // 
            this.toolStripStatusLabel6.Name = "toolStripStatusLabel6";
            this.toolStripStatusLabel6.Size = new System.Drawing.Size(114, 20);
            this.toolStripStatusLabel6.Text = "当前系统时间：";
            this.toolStripStatusLabel6.Click += new System.EventHandler(this.toolStripStatusLabel6_Click);
            // 
            // systemTime
            // 
            this.systemTime.Name = "systemTime";
            this.systemTime.Size = new System.Drawing.Size(0, 20);
            // 
            // time2
            // 
            this.time2.Name = "time2";
            this.time2.Size = new System.Drawing.Size(37, 20);
            this.time2.Text = "       ";
            this.time2.Click += new System.EventHandler(this.time2_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.工作量登记ToolStripMenuItem,
            this.效绩统计ToolStripMenuItem,
            this.工作量查询ToolStripMenuItem,
            this.个人管理ToolStripMenuItem,
            this.超级管理员ToolStripMenuItem,
            this.帮助ToolStripMenuItem,
            this.关于ToolStripMenuItem,
            this.退出系统ToolStripMenuItem,
            this.关闭系统ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1409, 28);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // 工作量登记ToolStripMenuItem
            // 
            this.工作量登记ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.教学统计ToolStripMenuItem,
            this.竞赛培训ToolStripMenuItem,
            this.科学研究ToolStripMenuItem,
            this.其他ToolStripMenuItem});
            this.工作量登记ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("工作量登记ToolStripMenuItem.Image")));
            this.工作量登记ToolStripMenuItem.Name = "工作量登记ToolStripMenuItem";
            this.工作量登记ToolStripMenuItem.Size = new System.Drawing.Size(116, 24);
            this.工作量登记ToolStripMenuItem.Text = "工作量登记";
            // 
            // 教学统计ToolStripMenuItem
            // 
            this.教学统计ToolStripMenuItem.Name = "教学统计ToolStripMenuItem";
            this.教学统计ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.教学统计ToolStripMenuItem.Text = "教学统计";
            this.教学统计ToolStripMenuItem.Click += new System.EventHandler(this.教学统计ToolStripMenuItem_Click);
            // 
            // 竞赛培训ToolStripMenuItem
            // 
            this.竞赛培训ToolStripMenuItem.Name = "竞赛培训ToolStripMenuItem";
            this.竞赛培训ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.竞赛培训ToolStripMenuItem.Text = "竞赛培训";
            this.竞赛培训ToolStripMenuItem.Click += new System.EventHandler(this.竞赛培训ToolStripMenuItem_Click);
            // 
            // 科学研究ToolStripMenuItem
            // 
            this.科学研究ToolStripMenuItem.Name = "科学研究ToolStripMenuItem";
            this.科学研究ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.科学研究ToolStripMenuItem.Text = "科学研究";
            // 
            // 其他ToolStripMenuItem
            // 
            this.其他ToolStripMenuItem.Name = "其他ToolStripMenuItem";
            this.其他ToolStripMenuItem.Size = new System.Drawing.Size(144, 26);
            this.其他ToolStripMenuItem.Text = "其他";
            // 
            // 效绩统计ToolStripMenuItem
            // 
            this.效绩统计ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("效绩统计ToolStripMenuItem.Image")));
            this.效绩统计ToolStripMenuItem.Name = "效绩统计ToolStripMenuItem";
            this.效绩统计ToolStripMenuItem.Size = new System.Drawing.Size(101, 24);
            this.效绩统计ToolStripMenuItem.Text = "绩效统计";
            this.效绩统计ToolStripMenuItem.Click += new System.EventHandler(this.效绩统计ToolStripMenuItem_Click);
            // 
            // 工作量查询ToolStripMenuItem
            // 
            this.工作量查询ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("工作量查询ToolStripMenuItem.Image")));
            this.工作量查询ToolStripMenuItem.Name = "工作量查询ToolStripMenuItem";
            this.工作量查询ToolStripMenuItem.Size = new System.Drawing.Size(101, 24);
            this.工作量查询ToolStripMenuItem.Text = "信息查改";
            // 
            // 个人管理ToolStripMenuItem
            // 
            this.个人管理ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("个人管理ToolStripMenuItem.Image")));
            this.个人管理ToolStripMenuItem.Name = "个人管理ToolStripMenuItem";
            this.个人管理ToolStripMenuItem.Size = new System.Drawing.Size(101, 24);
            this.个人管理ToolStripMenuItem.Text = "个人管理";
            this.个人管理ToolStripMenuItem.Click += new System.EventHandler(this.个人管理ToolStripMenuItem_Click);
            // 
            // 超级管理员ToolStripMenuItem
            // 
            this.超级管理员ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("超级管理员ToolStripMenuItem.Image")));
            this.超级管理员ToolStripMenuItem.Name = "超级管理员ToolStripMenuItem";
            this.超级管理员ToolStripMenuItem.Size = new System.Drawing.Size(116, 24);
            this.超级管理员ToolStripMenuItem.Text = "超级管理员";
            // 
            // 帮助ToolStripMenuItem
            // 
            this.帮助ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.计算器ToolStripMenuItem});
            this.帮助ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("帮助ToolStripMenuItem.Image")));
            this.帮助ToolStripMenuItem.Name = "帮助ToolStripMenuItem";
            this.帮助ToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
            this.帮助ToolStripMenuItem.Text = "帮助";
            // 
            // 计算器ToolStripMenuItem
            // 
            this.计算器ToolStripMenuItem.Name = "计算器ToolStripMenuItem";
            this.计算器ToolStripMenuItem.Size = new System.Drawing.Size(129, 26);
            this.计算器ToolStripMenuItem.Text = "计算器";
            this.计算器ToolStripMenuItem.Click += new System.EventHandler(this.计算器ToolStripMenuItem_Click);
            // 
            // 关于ToolStripMenuItem
            // 
            this.关于ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("关于ToolStripMenuItem.Image")));
            this.关于ToolStripMenuItem.Name = "关于ToolStripMenuItem";
            this.关于ToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
            this.关于ToolStripMenuItem.Text = "关于";
            this.关于ToolStripMenuItem.Click += new System.EventHandler(this.关于ToolStripMenuItem_Click);
            // 
            // 退出系统ToolStripMenuItem
            // 
            this.退出系统ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("退出系统ToolStripMenuItem.Image")));
            this.退出系统ToolStripMenuItem.Name = "退出系统ToolStripMenuItem";
            this.退出系统ToolStripMenuItem.Size = new System.Drawing.Size(101, 24);
            this.退出系统ToolStripMenuItem.Text = "退出登录";
            this.退出系统ToolStripMenuItem.Click += new System.EventHandler(this.退出系统ToolStripMenuItem_Click);
            // 
            // 关闭系统ToolStripMenuItem
            // 
            this.关闭系统ToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("关闭系统ToolStripMenuItem.Image")));
            this.关闭系统ToolStripMenuItem.Name = "关闭系统ToolStripMenuItem";
            this.关闭系统ToolStripMenuItem.Size = new System.Drawing.Size(101, 24);
            this.关闭系统ToolStripMenuItem.Text = "关闭系统";
            this.关闭系统ToolStripMenuItem.Click += new System.EventHandler(this.关闭系统ToolStripMenuItem_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1409, 847);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(1427, 894);
            this.MinimumSize = new System.Drawing.Size(1427, 894);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "毕方教师工作量统计系统";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel Tname;
        private System.Windows.Forms.ToolStripStatusLabel superManag;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel5;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel10;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel7;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel6;
        private System.Windows.Forms.ToolStripStatusLabel systemTime;
        private System.Windows.Forms.ToolStripStatusLabel time2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem 工作量登记ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 教学统计ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 竞赛培训ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 科学研究ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 其他ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 效绩统计ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 工作量查询ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 个人管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 超级管理员ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 帮助ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关于ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 退出系统ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 计算器ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 关闭系统ToolStripMenuItem;
    }
}