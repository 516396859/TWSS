﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace toolClass
{
    public class Class1
    {
        public static string GetTableId(string )
        {

            string tableId = "";
            return tableId;
        }
    }
}
